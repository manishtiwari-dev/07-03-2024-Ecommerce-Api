<?php

namespace Modules\Ecommerce\Models\Services;

use App\Helper\ApiHelper;
use App\Models\Country;
use Illuminate\Database\Eloquent\Builder;

use Modules\Ecommerce\Models\Product;
use Modules\Ecommerce\Models\ProductAttribute;
use Modules\Ecommerce\Models\Category;
use Modules\Ecommerce\Models\ProductPrice;
use Modules\Ecommerce\Models\ProductToCategory;
use Modules\Pcapi\Models\PcProduct;
use Illuminate\Support\Facades\Http;

class ProductServices
{

    // Attribute Price 

    public static function attributePrice($product_id, $options_id, $options_values_id)
    {
        $final_price = 0;
        $attribute_data = ProductAttribute::where('products_id', $product_id)->where('options_id', $options_id)
            ->where('options_values_id', $options_values_id)->first();
        if (!empty($attribute_data)) {
            $final_price = $attribute_data->options_values_price;
        }
        return $final_price;
    }


    //  Product Price List

    public static function ProductPrices($product_id)
    {
        $productDetail = Product::where(['product_id' => $product_id])->first();

        if (!empty($productDetail)) {
            if ($productDetail->source == 1) {
                if ($productDetail->product_price_type == 2) {
                    $bulk_product_price = ProductPrice::where('product_id', $product_id)->orderBy('product_qty', 'ASC')->get();
                    return $bulk_product_price;
                }
            } else {

                $bulk_product = PcProduct::where('products_id', $productDetail->source_id)->get();
                foreach ($bulk_product as $bulkPrc) {
                    $bulkPrc->product_qty = $bulkPrc->products_price1_qty;
                    $bulkPrc->sale_price = $bulkPrc->products_price1;
                }

                return $bulk_product;
            }
        }
    }


    public function getProductDetails($products_id, $languages_id = 1, $country = 99)
    {

        $sea_port = ApiHelper::getAddOnSetVal('pc_shipping_option_' . $country) == "sea_shipping" ? ApiHelper::getAddOnSetVal('pc_sea_port_' . $country) : '';

        $extra_param = [
            'country_id' => $country,
            'shipping_method' => ApiHelper::getAddOnSetVal('pc_shipping_option_' . $country),
            'profitMargin' =>  ApiHelper::getAddOnSetVal('pc_profit_margin'),
            'imprint_color' => 1,
            'imprint_location' => 22,
            'sea_port' => $sea_port,
        ];


        $parameters = ['product_id' => $products_id, 'languages_id' => $languages_id, 'options' => $extra_param];
        $apiurl = "https://promo-enterprise.com/api/product-details";



        $response = Http::post($apiurl, $parameters);

        $details_list = json_decode($response->getBody());

        return $details_list->data;
    }


    // GetSalePrice

    public static function GetSalePrice($product_id)
    {
        $sale_price = 0;
        $qty = 1;

        $bulkPrice = [];

        $productDetail = Product::where(['product_id' => $product_id])->first();

        if (!empty($productDetail)) {
            if ($productDetail->source == 1) {

                if ($productDetail->product_price_type == 1) {
                    $sale_price = $productDetail->sale_price;
                    $qty = 1;
                }

                if ($productDetail->product_price_type == 2) {
                    $bulk_product_price = ProductPrice::where('product_id', $productDetail->product_id)->orderBy('product_qty', 'ASC')->get();

                    foreach ($bulk_product_price as $key => $bulkPrc) {
                        $bulkPrice[$key]['product_qty'] = $bulkPrc->product_qty;
                        $bulkPrice[$key]['sale_price'] = $bulkPrc->sale_price;
                    }

                    $sale_price = number_format(reset($bulkPrice)['sale_price'], '2', '.', ',');
                    $qty = reset($bulkPrice)['product_qty'];
                }
            } else {

                $default_country = ApiHelper::getKeySetVal('default_country');
                $default_language = ApiHelper::getKeySetVal('default_language');


                if (!empty($default_country)) {
                    $country_data = Country::where('countries_iso_code_2', $default_country)->first();

                    $countries_id = $country_data->countries_id;

                    $prodetails = (new self)->getProductDetails($productDetail->source_id, $default_language, $countries_id);

                    foreach ($prodetails->productDetails->price as $key => $bulkPrc) {
                        $bulkPrice[$key]['product_qty'] = ((array)$prodetails->productDetails->qty)[$key];
                        $bulkPrice[$key]['sale_price'] = $bulkPrc;
                    }

                    $sale_price = number_format(reset($bulkPrice)['sale_price'], '2', '.', ',');
                    $qty = reset($bulkPrice)['product_qty'];
                }
            }
        }

        $res = [
            'qty' => $qty,
            'sale_price' => $sale_price,
            'bulkPrice' => $bulkPrice,
        ];

        return $res;
    }

    public static function findProduct($product_id, $desc = true)
    {
        $language_id =  ApiHelper::getKeySetVal('default_language');


        $product =  Product::with('productdescription', 'productAttribute')->where(['source' => 2, 'source_id' => $product_id])->first();

        return $product;

        // if (!empty($product)) {

        //     if ($desc) {
        //         $pr = $this->getProductDesc($product->product_id, $language_id);
        //         $product->products_name = ($pr == null) ? '' : $pr->products_name;
        //         $product->products_description = ($pr == null) ? '' : $pr->products_description;
        //         $product->product_details = ($pr == null) ? '' : $pr->product_details;
        //     }

        //     // relate with attach attributes
        //     $attributes = $product->productAttribute()->with('productOptions')->groupBy('options_id')->get();
        //     if (!empty($attributes)) {
        //         $attributes->map(function ($option) use ($product) {
        //             $option->option_name = $option->productOptions->products_options_name;
        //             $option->option_value_list = $product->productAttribute()->with('productOptionsValue')->where('options_id', $option->options_id)->get();
        //             return $option;
        //         });
        //     }
        //     $product->productAttribute = $attributes;
        // }
        // return $product;
    }

    public function getProductDesc($product_id, $language_id)
    {
        $desc = [];
        $product = Product::where('product_id', $product_id)->first();

        if ($product->source == 2) {
            $PcProductsService = (new self)->getProductDetails($product->source_id, $language_id);

            $desc = (object)$PcProductsService;
        } else
            $desc = $product->productdescription()->where('languages_id', $language_id)->first();

        return $desc;
    }
}
