<?php

namespace Modules\Ecommerce\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Ecommerce\Models\Category;
use Modules\Ecommerce\Models\Fields;
use Modules\Ecommerce\Models\Supplier;
use App\Models\Language;
use App\Models\Images;
use Modules\Ecommerce\Models\SeoMeta;
use Modules\Ecommerce\Models\ProductAttribute;
use Modules\Ecommerce\Models\ProductFeature;
use Modules\Ecommerce\Models\Services\ProductServices;


class Product extends Model
{
    use HasFactory;

    protected $primaryKey = 'product_id';

    protected $guarded = ['product_id'];


    public function getTable()
    {
        return config('dbtable.ecm_products');
    }

    public function productdescription_with_lang()
    {
        return $this->belongsToMany(Language::class, config('dbtable.ecm_products_description'), 'products_id', 'languages_id')->withPivot('products_name', 'products_description');
    }

    public function productAttribute()
    {
        return $this->hasMany(ProductAttribute::class, 'products_id', 'product_id');
    }

    public function productFeature()
    {
        return $this->hasMany(ProductFeature::class, 'product_id', 'product_id');
    }

    public function productPrice()
    {
        return $this->hasMany(ProductPrice::class, 'product_id', 'product_id');
    }


    public static function findProduct($product_id, $desc = true)
    {
        return ProductServices::findProduct($product_id, $desc);
    }


    public function productdescription()
    {
        return $this->hasMany(ProductDescription::class, 'products_id', 'product_id');
    }

    public function products_to_categories()
    {
        return $this->belongsToMany(Category::class, config('dbtable.ecm_products_to_categories'), 'products_id', 'categories_id');
    }

    public function products_to_supplier()
    {
        return $this->belongsToMany(Supplier::class, config('dbtable.ecm_products_to_supplier'), 'product_id', 'supplier_id');
    }

    public function products_to_seo()
    {
        return $this->hasMany(SeoMeta::class, 'reference_id', 'product_id');
    }

    public function products_to_images()
    {
        return $this->belongsTo(Images::class, 'product_image', 'images_id');
    }

    public function products_to_gallery()
    {
        return $this->belongsToMany(Images::class, config('dbtable.ecm_products_to_images'), 'product_id', 'images_id');
    }

    public function products_to_gallery_ids()
    {
        return $this->hasMany(config('dbtable.ecm_products_to_images'));
    }

    public function products_type_field_value()
    {
        return $this->belongsToMany(Fields::class, config('dbtable.ecm_products_type_field_value'), 'product_id', 'fields_id')->withPivot('field_value');
    }


    // Services

    public static function attributePrice($product_id, $options_id, $options_values_id)
    {
        return ProductServices::attributePrice($product_id, $options_id, $options_values_id);
    }

    public static function ProductPrices($product_id)
    {
        return ProductServices::ProductPrices($product_id);
    }

    public static function GetSalePrice($product_id)
    {
        return ProductServices::GetSalePrice($product_id);
    }
}
