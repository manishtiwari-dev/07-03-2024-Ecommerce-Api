<?php

namespace Modules\Ecommerce\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FeatureGroupContent extends Model
{
    use HasFactory;

    public $timestamps = false;

    protected $fillable = [
        'featured_group_id',
        'languages_id',
        'group_name',
        'group_title',
    ];


    public function getTable()
    {
        return config('dbtable.ecm_featured_group_content');
    }
}
